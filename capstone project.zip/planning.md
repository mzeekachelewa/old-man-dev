Design website layout; tools of trade, pen & paper.

Write out the HTML code

Test out all the links

Write out the CSS code

Make her pretty

#The list of 5 websites page3
https://longdogechallenge.com/
https://optical.toys/
https://checkbox.toys/scale/
https://paint.toys/calligram
https://www.youtube.com/
